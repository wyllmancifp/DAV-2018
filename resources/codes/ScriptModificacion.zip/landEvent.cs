﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SpeedRun {
    public class landEvent : MonoBehaviour {
        public GameObject player = null;

        public GameObject previousFather = null;

        private void OnCollisionEnter(Collision collision) {
            if (collision.transform.tag == "Player") {


                player.transform.parent = this.transform;
            }
        }

        private void OnCollisionExit(Collision collision) {
            if (collision.transform.tag == "Player") {
                player.transform.parent = previousFather.transform;
            }
        }
    }

}
