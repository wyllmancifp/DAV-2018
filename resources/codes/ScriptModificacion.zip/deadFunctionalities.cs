﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


namespace SpeedRun {
    public class deadFunctionalities : MonoBehaviour {

        public GameObject dead2DPanel = null;

        public int mainSceneIndex = 0;
        public int thisSceneIndex = 1;

        //private void OnTriggerEnter(Collider other) {
        //    if (other.tag == "Player") {
        //        dead2DPanel.SetActive(true);
        //    }
        //}

        private void OnCollisionEnter(Collision collision) {
            if (collision.transform.tag == "Player") {
                dead2DPanel.SetActive(true);
            }
        }

        public void retry() {
            SceneManager.LoadScene(thisSceneIndex);
        }

        public void back() {
            SceneManager.LoadScene(mainSceneIndex);
        }
    }
}
