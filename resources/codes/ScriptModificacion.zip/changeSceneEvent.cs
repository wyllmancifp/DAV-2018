﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SpeedRun {
    public class changeSceneEvent : MonoBehaviour {

        public int SceneIndex = 0;

        private void OnTriggerEnter(Collider other) {
            if (other.tag == "Player") {
                SceneManager.LoadScene(SceneIndex);
            }
        }
    }
}
